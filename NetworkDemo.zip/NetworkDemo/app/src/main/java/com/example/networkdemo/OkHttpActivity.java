package com.example.networkdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OkHttpActivity extends AppCompatActivity implements View.OnClickListener {
    private Button Get,Post,Update,Download;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok_http);
        Get=findViewById(R.id.bt_get);
        Post=findViewById(R.id.bt_post);
        Update=findViewById(R.id.bt_update);
        Download=findViewById(R.id.bt_download);
        Get.setOnClickListener(this);
        Post.setOnClickListener(this);
        Update.setOnClickListener(this);
        Download.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bt_get:
                break;
            case R.id.bt_post:
                break;
            case R.id.bt_update:
                break;
            case R.id.bt_download:
                break;
        }
    }
}
